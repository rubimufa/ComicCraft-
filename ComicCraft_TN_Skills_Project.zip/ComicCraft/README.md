# ComicCraft – AI Comic Story Creator using Gemini Models

## TN Skills Project

ComicCraft is a Generative AI web application that creates comic stories from a user's idea.

### Technology Stack

- Python
- FastAPI
- Google Gemini API
- Jinja2
- HTML
- CSS
- Uvicorn
- python-dotenv

## Project Workflow

### Epic 1 – Model Selection and Architecture
Story 1: Research and select the appropriate Generative AI model.
Story 2: Define the application architecture.
Story 3: Set up the development environment.

### Epic 2 – Core Functionalities Development
Story 1: Develop the core comic generation functionality.
Story 2: Implement the FastAPI backend for routing and user input.

### Epic 3 – routes.py Development
Story 1: Write the main application logic in routes.py.

### Epic 4 – Frontend Development
Story 1: Design and develop the user interface.
Story 2: Create dynamic templates using FastAPI Jinja2.

### Epic 5 – Deployment
Story 1: Prepare the application for local deployment.
Story 2: Test and verify local deployment.

## Setup

1. Open this folder in VS Code.

2. Create a virtual environment:

    python -m venv venv

3. Activate it on Windows:

    venv\Scripts\activate

4. Install dependencies:

    pip install -r requirements.txt

5. Create a file named `.env` by copying `.env.example`.

6. Put your Gemini API key in `.env`:

    GEMINI_API_KEY=YOUR_REAL_API_KEY

7. Run:

    uvicorn app.main:app --reload

8. Open:

    http://127.0.0.1:8000

## Health Check

    http://127.0.0.1:8000/health

## Main Files

app/main.py
    Starts FastAPI.

app/routes.py
    Handles routes and form input.

app/services/gemini_service.py
    Connects to Gemini and generates the comic.

app/templates/index.html
    Comic creation page.

app/templates/result.html
    Dynamic generated comic page.

app/static/style.css
    Frontend styling.

## Security

Never share your Gemini API key or upload `.env` to GitHub.
