import json
import os
import re

from dotenv import load_dotenv
from google import genai

load_dotenv()

API_KEY = os.getenv("GEMINI_API_KEY")
MODEL_NAME = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")

if not API_KEY:
    raise RuntimeError(
        "GEMINI_API_KEY is missing. Create a .env file and add your Gemini API key."
    )

client = genai.Client(api_key=API_KEY)


def clean_json(text: str) -> str:
    text = text.strip()
    text = re.sub(r"^```json\s*", "", text, flags=re.IGNORECASE)
    text = re.sub(r"^```\s*", "", text)
    text = re.sub(r"\s*```$", "", text)

    start = text.find("{")
    end = text.rfind("}")

    if start == -1 or end == -1:
        raise ValueError("Gemini did not return valid JSON.")

    return text[start:end + 1]


def generate_comic(
    story_idea: str,
    main_character: str,
    genre: str,
    mood: str,
    language: str,
    panels: int
):
    prompt = f"""
You are ComicCraft, an AI comic story creator.

Create an original, family-friendly comic using the following information.

Story idea: {story_idea}
Main character: {main_character}
Genre: {genre}
Mood: {mood}
Language: {language}
Number of panels: {panels}

Return ONLY valid JSON. Do not use Markdown.

Use exactly this structure:

{{
  "title": "Comic title",
  "summary": "Short summary",
  "characters": [
    {{
      "name": "Character name",
      "description": "Short visual/personality description"
    }}
  ],
  "panels": [
    {{
      "panel_number": 1,
      "scene": "What the reader sees",
      "character": "Character speaking",
      "dialogue": "Short comic dialogue",
      "caption": "Narrator caption",
      "image_prompt": "Detailed prompt for generating this panel image"
    }}
  ],
  "moral": "Moral or message"
}}

Rules:
- Generate exactly {panels} panels.
- Keep dialogue short and natural.
- Make each panel continue the story.
- Keep the story suitable for students.
- Use the requested language for title, summary, dialogue, captions and moral.
- Image prompts can remain detailed and descriptive.
"""

    response = client.models.generate_content(
        model=MODEL_NAME,
        contents=prompt
    )

    return json.loads(clean_json(response.text))
