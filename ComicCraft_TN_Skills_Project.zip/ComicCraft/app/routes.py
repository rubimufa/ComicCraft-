from fastapi import APIRouter, Request, Form
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

from app.services.gemini_service import generate_comic

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")


@router.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse(
        "index.html",
        {"request": request, "error": None}
    )


@router.post("/generate", response_class=HTMLResponse)
async def create_comic(
    request: Request,
    story_idea: str = Form(...),
    main_character: str = Form(...),
    genre: str = Form(...),
    mood: str = Form(...),
    language: str = Form(...),
    panels: int = Form(...)
):
    if not story_idea.strip() or not main_character.strip():
        return templates.TemplateResponse(
            "index.html",
            {
                "request": request,
                "error": "Please enter both a story idea and main character."
            }
        )

    try:
        comic = generate_comic(
            story_idea=story_idea,
            main_character=main_character,
            genre=genre,
            mood=mood,
            language=language,
            panels=panels
        )

        return templates.TemplateResponse(
            "result.html",
            {"request": request, "comic": comic}
        )

    except Exception as exc:
        return templates.TemplateResponse(
            "index.html",
            {
                "request": request,
                "error": f"Comic generation failed: {str(exc)}"
            }
        )
